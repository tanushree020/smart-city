import java.sql.*;
import java.util.*;
import java.util.regex.*;



class Users
{
	
	/*Checking if the password entered is valid or not 
	 * Conditions :- at least 1 small letter, at least 1 capital letter,
	 * at least 1 number, at least 1 special character [ @,#,$,%,^,&,*], no space and
	 * length of password between 8 to 15
	 * 
	 * ARGUMENTS :- String password --> password entered
	 * RETURN :- boolean --> true - Valid, false - Invalid
	 * */
	public boolean isValidPassword(String password)
	{
		String rgx = "^(?=.*[0-9])"+
					"(?=.*[a-z])"+
				     "(?=.*[A-Z])"+
					"(?=.*[@#$%^&*])"+
				     "(?=\\S+$)"+
					".{8,15}$";
		Pattern pattern = Pattern.compile(rgx);
		Matcher match = pattern.matcher(password);
		
		return match.matches();
	}
	
	
	/*Checking if the user name entered is valid or not
	 * Conditions :- Start with a capital letter or small letter or number ,
	 * after @ small letters and '.' are valid 
	 * 
	 * ARGUMENTS :- String username --> username entered by the user
	 * RETURN :-  boolean --> true - Valid, false - Invalid
	 * */
	private boolean isValidUsername(String username)
	{
		String rgx = "^[A-Za-z0-9]+@[a-z.]+$";
		Pattern pattern = Pattern.compile(rgx);
		Matcher match = pattern.matcher(username);
		return match.matches();
	}
	
	
	/*Creating a new account. Can either be the common people or the municipal authority
	 * User :- Entering the user name and password 
	 *        Checked if it is valid or not
	 *        If valid then account created
	 *        Else not
	 *        -> Password is unique or not is also checked
	 *        
	 * RETURN :- boolean --> true - Account created, false - Account not created 
	 * */
	public boolean createAccount()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Create account ");
		System.out.println("Enter name : ");
		String name = scan.nextLine();
		System.out.println("Enter username : ");
		String username = scan.nextLine();
		System.out.println("Enter password : ");
		String password = scan.nextLine();
		boolean fp = isValidPassword(password);
		boolean fu = isValidUsername(username);
		boolean f1 = false;
		if(!fp || !fu)
		{
			//System.out.println("Account not created ");
			f1 = false;
		}
		else
		{
			try
			{
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
				System.out.println("Successful connection");
				if(con != null)
				{
					Statement st = con.createStatement();
					st.executeQuery("USE SmartCity");
					PreparedStatement pst = con.prepareStatement("SELECT * FROM User WHERE Password = ?");
					pst.setString(1, password);
					ResultSet rs = pst.executeQuery();
					if(!rs.next())
					{
						System.out.println("Unique password");
						PreparedStatement pst1 = con.prepareStatement("INSERT INTO User VALUES(?,?,?)");
						pst1.setString(1, name);
						pst1.setString(2, username);
						pst1.setString(3, password);
						pst1.executeUpdate();
						f1 = true;
					}
					else
					{
						System.out.println("Password already exist");
					}
					
				}
				else
				{
					System.out.println("Connection unsuccessfull");
				}
				
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
			
		}
		return f1;
	}
	
	
	/*If the user wants to change their password
	 * User :-  Enters the user name and the new password
	 * 			Checked if the password is valid or not
	 * 			If valid -> The password is updated in the database
	 * 			else not valid -> password not updated in the database
	 * */
	public void changePassword()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter user name : ");
		String userName = scan.next();
		System.out.println("Enter the new password : ");
		String newPassword = scan.nextLine();
		boolean f = isValidPassword(newPassword);
		if(f)
		{
			try
			{
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
				Statement st = con.createStatement();
				st.executeQuery("USE SmartCity");
				PreparedStatement pst = con.prepareStatement("UPDATE User SET Password = ? WHERE UserName = ?");
				pst.setString(1,newPassword);
				pst.setString(2, userName);
				ResultSet rs = pst.executeQuery();
				if(!rs.next())
				{
					System.out.println("User name incorrect");
				}
				else
				{
					System.out.println("Password changed");
					//f = true;
					//System.out.println(rs.getString("Name") + "    " + rs.getString("UserName") + "    " + rs.getString("Password"));
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		else
		{
			System.out.println("Password not valid");
		}
	}
	
	
	/*Menu driven function for "common people" user
	 * Sign up --> Create account   -- true - account created, false - account not created
	 * Login --> login or change password
	 * If login  :- user name and password is checked and then the rate and review process is
	 * continued
	 * */
	void commonPeople()
	{
		Scanner scan = new Scanner(System.in);
		CommonPeople c = new CommonPeople();
		System.out.println("\n1. Sign up\n2. Login in");
		System.out.println("Enter your choice : ");
		int ch = scan.nextInt();
		int co  = 0;
		switch(ch)
		{
			case 1:
				boolean f1 = createAccount();
				if(f1)
				{
					System.out.println("Successfully account created");
				}
				else
				{
					System.out.println("Account not created");
				}
				break;
			case 2:
				System.out.println("\n1. Login\n2. Change password");
				System.out.println("Enter your choice  : ");
				co = scan.nextInt();
				switch(co)
				{
					case 1:
						c.CommonPeopleCheck();
						break;
					case 2:
						changePassword();
						break;
					default:
						System.out.println("Wrong choice");
				}
				break;
			default:
				System.out.println("Wrong choice ");
		}
		
	}
	
	
	/*Function for the tourist
	 * Object of tourist class
	 * Calls the give Rate and review function
	 * */
	void tourists()
	{
		Tourists t = new Tourists();
		t.give();
	}
	
	
	/*Menu driven function for "municipal authority"
	 * Sign up --> Create account   -- true - account created, false - account not created
	 * Login --> login or change password
	 * If login  :- user name and password is checked and then the rate and review process is
	 * continued
	 * */
	void muncipalAuthority()
	{
		Scanner scan = new Scanner(System.in);
		MunicipalAuthority c = new MunicipalAuthority();
		System.out.println("\n1. Sign up\n2. Login in");
		System.out.println("Enter your choice : ");
		int ch = scan.nextInt();
		int co = 0;
		switch(ch)
		{
			case 1:
				boolean f1 = createAccount();
				if(f1)
				{
					System.out.println("Successfully account created");
				}
				else
				{
					System.out.println("Account not created");
				}
				break;
			case 2:
				System.out.println("\n1. Login\n2. Change password");
				System.out.println("Enter your choice  : ");
				co = scan.nextInt();
				switch(co)
				{
					case 1:
						c.MunicipalAuthorityCheck();
						break;
					case 2:
						changePassword();
						break;
					default:
						System.out.println("Wrong choice");
				}
				break;
			default:
				System.out.println("Wrong choice ");
		}
	}

}


//----------------------------------------------------------------------------------------

/*Administration class has the main function
 * Menu driven
 * 3 users :- common people, tourist, municipal authority
 * According to the user, one of them is selected 
 * */

public class Adminstration {
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner scan = new Scanner(System.in);
		//CommonPeople c = new CommonPeople();
		int ch = 0;
		Users u = new Users();
		System.out.println("1. Common people\n2. Tourist \n3. Municipal Authority");
		System.out.println("Enter your choice : ");
		ch = scan.nextInt();
		switch(ch)
		{
			case 1:
				u.commonPeople();
				break;
			case 2:
				u.tourists();
				break;
			case 3:
				u.muncipalAuthority();
				break;
			default:
				System.out.println("WRONG CHOICE !!");
		}

	}

}
