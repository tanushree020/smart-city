import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class CommonPeoplePlaces 
{
	
	
	/*PRIVATE function
	 * Inserts the users name, rate and review into the database
	 * 
	 * ARGUMENTS :- String placeName - name of the place to be given rate to 
	 * 									the place table is used
	 * 				String userName - name of the user giving the rating to the place
	 * 				double rate - valid rate that is given to the place
	 * 				String review - valid review that is given to the user
	 * */
	private void insertingRateAndReview(String placeName, String userName, double rate, String review)
	{
		Scanner scan = new Scanner (System.in);
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			System.out.println("Successful connection");
			if(con != null)
			{
				Statement st = con.createStatement();
				st.executeQuery("USE SmartCity");
				String sqlStatement = "INSERT INTO " + placeName + " VALUES(?,?,?)";
				PreparedStatement pst = con.prepareStatement(sqlStatement);
				sqlStatement  = "SELECT * FROM " + placeName;
 				insertRateAndReview(userName, rate, review,pst);
				ResultSet rs = st.executeQuery(sqlStatement);
				while(rs.next())
				{
					System.out.println(rs.getString("Name") + "    " + rs.getDouble("Rate") + "    " + rs.getString("Review"));
				}
				System.out.println("---------------");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}
	
	
	/*PRIVATE function
	 * Inserting the users name, rate and review into the database
	 * ARGUMENTS :- String userName - users name
	 * 				double rate - rate given by the user
	 * 				String review - review given by the user
	 * 				PreparedStatement pst - used for entering the name, rate and review into the database
	 * */
	private void insertRateAndReview(String userName, double rate, String review, PreparedStatement pst)
	{
		try 
		{
			pst.setString(1, userName);
			pst.setDouble(2, rate);
			pst.setString(3, review);
			pst.executeUpdate();
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	
	/*PUBLIC function
	 * Called by the "Common people " class
	 * Calls the insertingRateAndReview function
	 * ARGUMENTS :-  String placeName - place name to be given rating to
	 * 				String userName - name of the user
	 * 				double rate - valid rate given to the place
	 * 				String review - valid review given to the place
	 * */
	public void insert(String placeName, String userName, double rate, String review)
	{
		insertingRateAndReview(placeName, userName, rate, review);
	}
	
	
	/*PUBLIC function
	 * Calls the gettingRate function
	 * ARGUMENTS :-  String placeName - name of the place to get the rate
	 * RETURN :- double --> returns the rate given to the place
	 * */
	public double getRate(String placeName)
	{
		double rate = gettingRate(placeName);
		return rate;
	}
	
	
	/*PRIVATE function
	 * Returns the rate of the place name
	 * ARGUMENT :- String placeName - Name of the place to get the rating of
	 * RETURN :- double - rate of the place 
	 * */
	private double gettingRate(String placeName)
	{
		double rate = 0.0;
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			System.out.println("Successful connection");
			if(con != null)
			{
				Statement st = con.createStatement();
				st.executeQuery("USE SmartCity");
				String sqlStatement = "SELECT AVG(Rate) AS AverageRate FROM "+  placeName;
				PreparedStatement pst = con.prepareStatement(sqlStatement);
				ResultSet rs = pst.executeQuery();
				if(rs.next())
				{
					rate = rs.getDouble("AverageRate");
				}
			}
				
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		return rate;
	}
	
	
	/*PUBLIC function
	 * Calls the gettingReview function
	 * ARGUMENT :- String placeName - name of the place to get the review of
	 * */
	public void getReview(String placeName)
	{
		gettingReview(placeName);
	}
	
	
	/*PRIVATE function
	 * Displays the reviews along with the users name and rate of those
	 * users who have given the rate less than equal to 2
	 * ARGUMENT :- String placeName - name of place to get the review of
	 * */
	private void gettingReview(String placeName)
	{
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			System.out.println("Successful connection");
			if(con != null)
			{
				Statement st = con.createStatement();
				st.executeQuery("USE SmartCity");
				String sqlStatement = "SELECT * FROM " + placeName + " WHERE Rate <= 2.0";
				PreparedStatement pst = con.prepareStatement(sqlStatement);
				ResultSet rs = pst.executeQuery();
				while(rs.next())
				{
					System.out.println(rs.getString("Name") + "    " +  rs.getDouble("Rate") + 
							"    " + rs.getString("Review"));
				}
				
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
	}

}
