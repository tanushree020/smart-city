import java.util.*;
import java.sql.*;


public class MunicipalAuthority 
{
	private TouristDestinations td;
	private CommonPeoplePlaces cpp;
	
	MunicipalAuthority()
	{ 
		td = new TouristDestinations ();
		cpp = new CommonPeoplePlaces();
	}
	
	
	/* PUBLIC function called by the User class
	 * Calls the checkUserAndPass function 
	 * If true -> calls getRateAndReview
	 * */
	public void MunicipalAuthorityCheck()
	{
		boolean f = checkUserAndPass();
		int c = 0;
		Scanner scan = new Scanner(System.in);
		if(f)
		{
			getRateAndReview();
			
		}	
		return ;
	}
	
	
	/*PRIVATE function
	 * User enters the choice from park, bus stop, parking lot and tourist destination
	 * Select from the list of places for that place
	 * Gets the rate of the place
	 * 			for park, bus stop and parking lot 
	 * 			if rate less than equal to 2 then getReview function is called
	 * 			for tourist destination
	 * 			if rate less than equal to 3 then getReview function is called
	 * */
	private void getRateAndReview()
	{
		Scanner scan = new Scanner(System.in);
		String place = "";
		System.out.println("1. Park\n2. Bus Stop\n3. Parking Lots\n4. Tourist destinations");
		System.out.println("Enter your choice : ");
		int c = scan.nextInt();
		if(c == 1)
		{
			String parkNames[] = {"AqsaPark","Okayamafriendshipgarden","Oshoteathpark"};
			System.out.println("1. Aqsa Park\n2. Okayama friendship garden\n3. Osho teath park");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			place = parkNames[ch-1];
		}
		else if (c == 2)
		{
			String busStopNames[] = {"Hadspar","Swargate","VimanNagar"};
			System.out.println("1. Hadpsar\n2. Swargate\n3. Viman Nagar");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			place = busStopNames[ch-1];
		}
		else if (c == 3)
		{
			String parkingLotNames[] = {"pmcparkinglot","rrparkinglot","sarasbaugparkinglot"};
			System.out.println("1. PMC Parking Lot\n2. RR Parkinglot\n3. Saras Baug Parkinglot");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			place = parkingLotNames[ch-1];
		}
		else
		{
			String touristDestNames[] = {"khadakwasladam","shaniwarvada","sinhagadfort"};
			System.out.println("1. Khadakwasla Dam\n2. Shaniwarvada\n3. Sinhagad Fort");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			place = touristDestNames[ch-1];
			double rate = td.getRate(touristDestNames[ch-1]); 
			if(rate < 3.0)
			{
				System.out.println("Rate very less");
				td.getReview(place);
			}
			else
			{
				System.out.println("good rating");
			}
			return;
		}
		
		double rate = cpp.getRate(place); 
		if(rate < 2.0)
		{
			System.out.println("Rate very less");
			cpp.getReview(place);
		}
		else
		{
			System.out.println("good rating");
		}
		
	}
	
	
	/*PRIVATE function 
	 * User :- enters the user name and password 
	 *        user name and password checked in the database
	 * RETURN :- boolean --> true - account in the database, false - account no in database
	 * */
	private boolean checkUserAndPass()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your username : ");
		String user = scan.nextLine();
		System.out.println("Enter your password : ");
		String pass = scan.nextLine();
		boolean f = false;
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			Statement st = con.createStatement();
			st.executeQuery("USE SmartCity");
			PreparedStatement pst = con.prepareStatement("SELECT * FROM User WHERE Password = ? AND UserName = ?");
			pst.setString(1,pass);
			pst.setString(2, user);
			ResultSet rs = pst.executeQuery();
			if(!rs.next())
			{
				System.out.println("Password or User name incorrect");
			}
			else
			{
				f = true;
				System.out.println(rs.getString("UserName") + "    " + rs.getString("Password"));
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return f;
	}


}
