import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.*;


public class CommonPeople 
{
	private String password;
	private String name;
	private CommonPeoplePlaces cpp;
	
	CommonPeople()
	{
		password = "";
		name = "";	
		cpp = new CommonPeoplePlaces();
	}
	
	CommonPeople(String name,String password)
	{
		this.password = password;
		this.name = name;
	
		cpp = new CommonPeoplePlaces();
		
	}
	
	
	/* PUBLIC function called by the User class
	 * Calls the checkUserAndPass function 
	 * If true -> calls giveRateAndReview
	 * */
	public void CommonPeopleCheck()
	{
		boolean f = checkUserAndPass();
		int c = 0;
		Scanner scan = new Scanner(System.in);
		//System.out.println(f);
		if(f)
		{
			giveRateAndReview();
		}
	}	
	
	
	/*PRIVATE function 
	 * User :- enters the user name and password 
	 *        user name and password checked in the database
	 * RETURN :- boolean --> true - account in the database, false - account no in database
	 * */
	private boolean checkUserAndPass()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter your username : ");
		String user = scan.nextLine();
		System.out.println("Enter your password : ");
		String pass = scan.nextLine();
		boolean f = false;
		try
		{
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			Statement st = con.createStatement();
			st.executeQuery("USE SmartCity");
			PreparedStatement pst = con.prepareStatement("SELECT * FROM User WHERE Password = ? AND UserName = ?");
			pst.setString(1,pass);
			pst.setString(2, user);
			ResultSet rs = pst.executeQuery();
			if(!rs.next())
			{
				System.out.println("Password or User name incorrect");
			}
			else
			{
				f = true;
				name = rs.getString("Name");
				System.out.println(rs.getString("Name") + "    " + rs.getString("UserName") + "    " + rs.getString("Password"));
			}
		}
		catch(Exception e)
		{
			System.out.println(e.getMessage());
		}
		
		return f;
	}
	
	
	/*PRIVATE function
	 * User chooses from park, bus stop and parking lot,
	 * and then choose the place name from the list ,
	 * gives rate and review
	 * 		RATE :- is checked if less than 5 or not
	 * 				if not - user asked to enter the rate again
	 * 		REVIEW :- is checked if the number of characters is less than 150 characters or not
	 * 				if not - user asked to enter the review again
	 * 
	 * Call the "Common people places class" insert function
	 * Pass the users name, place name, rate and review
	 * */
	private void giveRateAndReview()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("1. Park\n2. Bus Stop\n3. Parking Lots");
		System.out.println("Enter your choice : ");
		int c = scan.nextInt();
		String placeName = "";
		if(c == 1)
		{
			String parkNames[] = {"AqsaPark","Okayamafriendshipgarden","Oshoteathpark"};
			//list of park places
			System.out.println("1. Aqsa Park\n2. Okayama friendship garden\n3. Osho teath park");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			placeName = parkNames[ch-1];
		}
		else if(c == 2)
		{
			String busStopNames[] = {"Hadspar","Swargate","VimanNagar"};
			System.out.println("1. Hadpsar\n2. Swargate\n3. Viman Nagar");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			placeName = busStopNames[ch-1];
		}
		else
		{
			String parkingLotNames[] = {"pmcparkinglot","rrparkinglot","sarasbaugparkinglot"};
			System.out.println("1. PMC Parking Lot\n2. RR Parkinglot\n3. Saras Baug Parkinglot");
			System.out.println("Enter your choice");
			int ch = scan.nextInt();
			placeName = parkingLotNames[ch-1];
		}
		System.out.println("Enter your rate only out of 5 : ");
		double rate = scan.nextDouble();
		scan.nextLine();
		while(rate > 5.0)
		{
			System.out.println("Rate greater than 5.0");
			System.out.println("Please enter the rate only out of 5 : ");
			rate = scan.nextDouble();
			scan.nextLine();
		}
		System.out.println("Enter your review (The number of characters should be less than 150 ) : ");
		String review = scan.nextLine();
		while(review.length() > 150)
		{
			System.out.println("Review is greater than 150 characters ");
			System.out.println("Please enter your review with number of characters less than 150 : ");
			review = scan.nextLine();
		}
		cpp.insert(placeName,name, rate, review);
	}
}
