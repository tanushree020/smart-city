package Smart_City;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class CommonPeoplePlaces {
	private String place;
	private String user;
	private double Rate;
	private String Review;
	public CommonPeoplePlaces(){
		place="";
		user="";
		Rate=0.0;
		Review="";
	}
	CommonPeoplePlaces(String user,double Rate, String Review){
		this.user=user;
		this.Rate=Rate;
		this.Review=Review;
	}


	public boolean insertingRateAndReview(String placeName, String userName, double rate, String review)
    {
        boolean f = false;
       
        try
        {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
           
            if(con != null)
            {
                Statement st = con.createStatement();
                st.executeQuery("USE SmartCity");
                String sqlStatement = "INSERT INTO " + placeName + " VALUES(?,?,?)";
                PreparedStatement pst = con.prepareStatement(sqlStatement);
                sqlStatement  = "SELECT * FROM " + placeName;
                 insertRateAndReview(userName, rate, review,pst);
                ResultSet rs = st.executeQuery(sqlStatement);
                f = true;
                while(rs.next())
                {
                    System.out.println(rs.getString("Name") + "    " + rs.getDouble("Rate") + "    " + rs.getString("Review"));
                }
               
            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return f;
    }


    /*PRIVATE function
     * Inserting the users name, rate and review into the database
     * ARGUMENTS :- String userName - users name
     *                 double rate - rate given by the user
     *                 String review - review given by the user
     *                 PreparedStatement pst - used for entering the name, rate and review into the database
     * */
    private void insertRateAndReview(String userName, double rate, String review, PreparedStatement pst)
    {
        try
        {
            pst.setString(1, userName);
            pst.setDouble(2, rate);
            pst.setString(3, review);
            pst.executeUpdate();
        }
        catch (SQLException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }
  


    /*PUBLIC function
     * Calls the gettingRate function
     * ARGUMENTS :-  String placeName - name of the place to get the rate
     * RETURN :- double --> returns the rate given to the place
     * */
    public double getRate(String placeName)
    {
        double rate = gettingRate(placeName);
        return rate;
    }


    /*PRIVATE function
     * Returns the rate of the place name
     * ARGUMENT :- String placeName - Name of the place to get the rating of
     * RETURN :- double - rate of the place
     * */
    private double gettingRate(String placeName)
    {
        double rate = 0.0;
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
            System.out.println("Successful connection");
            if(con != null)
            {
                Statement st = con.createStatement();
                st.executeQuery("USE SmartCity");
                String sqlStatement = "SELECT AVG(Rate) AS AverageRate FROM "+  placeName;
                PreparedStatement pst = con.prepareStatement(sqlStatement);
                ResultSet rs = pst.executeQuery();
                if(rs.next())
                {
                    rate = rs.getDouble("AverageRate");
                }
            }

        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return rate;
    }


    /*PUBLIC function
     * Calls the gettingReview function
     * ARGUMENT :- String placeName - name of the place to get the review of
     * */
    public ArrayList<CommonPeoplePlaces> getReview(String placeName)
    {
        return gettingReview(placeName);
    }


    /*PRIVATE function
     * Displays the reviews along with the users name and rate of those
     * users who have given the rate less than equal to 2
     * ARGUMENT :- String placeName - name of place to get the review of
     * */
    private ArrayList<CommonPeoplePlaces> gettingReview(String placeName)
    {
    	ArrayList<CommonPeoplePlaces> cp=new ArrayList<CommonPeoplePlaces>();
        try
        {
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
            System.out.println("Successful connection");
            if(con != null)
            {
                Statement st = con.createStatement();
                st.executeQuery("USE SmartCity");
                String sqlStatement = "SELECT * FROM " + placeName + " WHERE Rate <= 2.0";
                PreparedStatement pst = con.prepareStatement(sqlStatement);
                ResultSet rs = pst.executeQuery();
                while(rs.next())
                {
                	user=rs.getString("Name");
                	Rate = rs.getDouble("Rate");
                	Review=rs.getString("Review");
                	CommonPeoplePlaces c = new CommonPeoplePlaces(user,Rate,Review);
                	cp.add(c);
                  
                }

            }
        }
        catch(Exception e)
        {
            System.out.println(e.getMessage());
        }
        return cp;
        
    }
    public String getuser() {
    	return user;
    }
    public String getreview() {
    	return Review;
    }
    public double getrate() {
    	return Rate;
    }
  
}
