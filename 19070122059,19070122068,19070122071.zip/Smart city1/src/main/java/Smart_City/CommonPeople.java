package Smart_City;

//import java.beans.Statement;
//import java.sql.DriverManager;
import java.sql.*;
//import com.sun.jdi.connect.spi.Connection;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CommonPeople {
	private String password;
    private String name;
    //private CommonPeoplePlaces cpp;

    public CommonPeople()
    {
        password = "";
        name = "";   
        //cpp = new CommonPeoplePlaces();
    }

    CommonPeople(String name,String password)
    {
        this.password = password;
        this.name = name;

        //cpp = new CommonPeoplePlaces();

    }

public boolean checkUserAndPass(String user, String pass)
    {
        /*Scanner scan = new Scanner(System.in);
        System.out.println("Enter your username : ");
        String user = scan.nextLine();
        System.out.println("Enter your password : ");
        String pass = scan.nextLine();*/
        boolean f = false;
        try
        {
            //System.out.println("Hi");
            Class.forName("com.mysql.jdbc.Driver");
            //Class.forName("java.sql.Driver");
            //System.out.println("Hi");
            Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
            //System.out.println("Hola");
            Statement st = ((java.sql.Connection) con).createStatement();
            //String query = "SELECT * FROM User WHERE Password = "+ pass + " AND UserName = " + user;
            //System.out.println("Hello : ");
            st.executeQuery("USE SmartCity");
            //st.execute(query);
            PreparedStatement pst = ((java.sql.Connection) con).prepareStatement("SELECT * FROM User WHERE Password = ? AND UserName = ?");
            pst.setString(1,pass);
            pst.setString(2, user);
            ResultSet rs = pst.executeQuery();
            if(!rs.next())
            {
                System.out.println("Password or User name incorrect");
            }
            else
            {
                f = true;
                name = rs.getString("Name");
                //System.out.println(rs.getString("Name") + "    " + rs.getString("UserName") + "    " + rs.getString("Password"));
            }
        }
        catch(ClassNotFoundException e)
        {
            //System.out.println(e.getMessage());
            //System.out.println("Record not found");
            System.out.println("inside class not found ");
            System.out.println(e.getMessage());

        }
        catch(SQLException e1)
        {
            System.out.println(e1.getMessage());
            System.out.println(e1.getSQLState());
            System.out.println("Inside sql exception");
        }

        return f;
    }


    public String getName()
    {
        return name;
    }
    public boolean isValidPassword(String password)
    {
        String rgx = "^(?=.*[0-9])"+
                    "(?=.*[a-z])"+
                     "(?=.*[A-Z])"+
                    "(?=.*[@#$%^&*])"+
                     "(?=\\S+$)"+
                    ".{8,15}$";
        Pattern pattern = Pattern.compile(rgx);
        Matcher match = pattern.matcher(password);

        return match.matches();
    }


    /*Checking if the user name entered is valid or not
     * Conditions :- Start with a capital letter or small letter or number ,
     * after @ small letters and '.' are valid
     *
     * ARGUMENTS :- String username --> username entered by the user
     * RETURN :-  boolean --> true - Valid, false - Invalid
     * */
    private boolean isValidUsername(String username)
    {
        String rgx = "^[A-Za-z0-9]+@[a-z.]+$";
        Pattern pattern = Pattern.compile(rgx);
        Matcher match = pattern.matcher(username);
        return match.matches();
    }

    public boolean SignUp(String name, String username, String password)
    {
        boolean f = false;
        boolean fp = isValidPassword(password);
        boolean fu = isValidUsername(username);
        if(!fp || !fu)
        {
            //System.out.println("Account not created ");
            f = false;
        }
        else
        {
            try
            {
                Class.forName("com.mysql.jdbc.Driver");
                Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
                System.out.println("Successful connection");
                if(con != null)
                {
                    Statement st = ((java.sql.Connection) con).createStatement();
                    st.executeQuery("USE SmartCity");
                    PreparedStatement pst = ((java.sql.Connection) con).prepareStatement("SELECT * FROM User WHERE Password = ? AND Username=?");
                    pst.setString(1, password);
                    pst.setString(2, username);
                    ResultSet rs = pst.executeQuery();
                    if(!rs.next())
                    {
                        System.out.println("Unique password");
                        PreparedStatement pst1 = ((java.sql.Connection) con).prepareStatement("INSERT INTO User VALUES(?,?,?)");
                        pst1.setString(1, name);
                        pst1.setString(2, username);
                        pst1.setString(3, password);
                        pst1.executeUpdate();
                        f = true;
                    }
                    else
                    {
                        System.out.println("Password already exist");
                    }

                }
                else
                {
                    System.out.println("Connection unsuccessfull");
                }

            }
            catch(Exception e)
            {
                System.out.println(e.getMessage());
            }

        }
        //return f1;
        return f;

    }
    public boolean changePassword(String userName , String newPassword)
	{
    	boolean a =false;
		boolean f = isValidPassword(newPassword);
		if(f)
		{
			try
			{
				Class.forName("com.mysql.jdbc.Driver");
				Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
				Statement st = con.createStatement();
				st.executeQuery("USE SmartCity");
				PreparedStatement pst = con.prepareStatement("UPDATE User SET Password = ? WHERE UserName = ?");
				pst.setString(1,newPassword);
				pst.setString(2, userName);
				int rs = pst.executeUpdate();
				if(rs==0)
				{
					System.out.println("User name incorrect");
				}
				else
				{
					System.out.println("Password changed");
					a = true;
					
					//System.out.println(rs.getString("Name") + "    " + rs.getString("UserName") + "    " + rs.getString("Password"));
				}
			}
			catch(Exception e)
			{
				System.out.println(e.getMessage());
			}
		}
		else
		{
			System.out.println("Password not valid");
		}
		return a;
	}
	
	


}
