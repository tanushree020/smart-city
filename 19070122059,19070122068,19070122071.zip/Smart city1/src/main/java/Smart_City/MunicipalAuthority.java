package Smart_City;

import java.util.*;
import java.sql.*;


public class MunicipalAuthority 
{
	
	private String name;
	public String getName() {
		return name;
	}
	
	public MunicipalAuthority()
	{ 
		
		name= " ";
	}
	
	
	
	
	/*PRIVATE function 
	 * User :- enters the user name and password 
	 *        user name and password checked in the database
	 * RETURN :- boolean --> true - account in the database, false - account no in database
	 * */
	public boolean checkUserAndPass(String user, String pass)
	{
		
		boolean f = false;
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306","root","student");
			Statement st = con.createStatement();
			st.executeQuery("USE SmartCity");
			PreparedStatement pst = con.prepareStatement("SELECT * FROM User WHERE Password = ? AND UserName = ?");
			pst.setString(1,pass);
			pst.setString(2, user);
			ResultSet rs = pst.executeQuery();
			if(!rs.next())
			{
				//System.out.println("Password or User name incorrect");
			}
			else
			{
				f = true;
				name=rs.getString("Name");
				
			}
		}
		catch(ClassNotFoundException e)
		{
			
			System.out.println("inside class not found ");
			System.out.println(e.getMessage());
			
		}
		catch(SQLException e1)
		{
			System.out.println(e1.getMessage());
			System.out.println(e1.getSQLState());
			System.out.println("Inside sql exception");
		}
		
		
		return f;
	}
	

}
