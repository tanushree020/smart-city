package Smart_City;

import java.sql.*;
import java.util.*;


public class Tourists 
{
	private TouristDestinations td;
	
	Tourists()
	{
		td = new TouristDestinations ();
	}
	
	
	/*PUBLIC function
	 * Called by the user class
	 * Calls the giveRateAndReview function
	 * */
	public void give()
	{
		giveRateAndReview();
	}
	
	
	/*PRIVATE function
	 * User chooses from the place name from the list ,
	 * gives rate and review
	 * 		RATE :- is checked if less than 5 or not
	 * 				if not - user asked to enter the rate again
	 * 		REVIEW :- is checked if the number of characters is less than 150 characters or not
	 * 				if not - user asked to enter the review again
	 * 
	 * Call the "Tourist destination class" insert function
	 * Pass the place name, rate and review
	 * */
	private void giveRateAndReview()
	{
		Scanner scan = new Scanner(System.in);
		System.out.println("Enter the tourist destination place to rate : ");
		String touristDest = scan.nextLine();
		System.out.println("Enter your rate only out of 5 : ");
		double rate = scan.nextDouble();
		scan.nextLine();
		while(rate > 5.0)
		{
			System.out.println("Rate greater than 5.0");
			System.out.println("Please enter the rate only out of 5 : ");
			rate = scan.nextDouble();
			scan.nextLine();
		}
		System.out.println("Enter your rate (The number of characters should be less than 150 ) : ");
		String review = scan.nextLine();
		while(review.length() > 150)
		{
			System.out.println("Review is greater than 150 characters ");
			System.out.println("Please enter your review with number of characters less than 150 : ");
			review = scan.nextLine();
		}
		td.insert(touristDest, rate, review);
	}
}

